<?php
session_start();
$link=mysqli_connect("localhost","root","","codher");
$_SESSION['t1']=$_POST['t1'];
$_SESSION['t2']=$_POST['t2'];
$_SESSION['racc']=$_POST['racc'];
$_SESSION['amt']=$_POST['amt'];
?>

<form action="pinvalidate2.php" method="post">
    <input type="password" name="p" placeholder="6 digit pin"/>
    <button type="submit" class="button">Enter</button>
</form>