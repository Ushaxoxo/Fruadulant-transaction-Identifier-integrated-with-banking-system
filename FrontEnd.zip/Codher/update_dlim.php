<form action="update_dlim2.php" method="post">
    <input type="number" name="dval" placeholder="New Daily Limit"/>
    <button type="submit" class="button">Confirm</button>
</form>
