
<head>
    <link rel="stylesheet" href="navstyle.css">
</head>
<div id="mySidenav" class="sidenav">
  <a href="javascript:void(0)" class="closebtn" onclick="closeNav()">&times;</a>
  <a class="active" href="myacc.php">My Account</a>
  <a href="home.php">Banking</a>
  <a href="his.php">History</a>
</div>

<span style="font-size:30px;cursor:pointer;color:rgba(40,57,101,.9);" onclick="openNav()">&#9776;</span>

<script>
function openNav() {
  document.getElementById("mySidenav").style.width = "250px";
}

function closeNav() {
  document.getElementById("mySidenav").style.width = "0";
}
</script>

<body style="background-image:url(bank3.jpg); background-repeat: no-repeat; background-size: cover;">

<?php
error_reporting(E_ALL & ~E_WARNING);
session_start();
$link=mysqli_connect("localhost","root","","codher");
$query="SELECT balance,dlim,min_bal FROM accounts WHERE acc_no='$_SESSION[an]'";
if($result=mysqli_query($link,$query)){
    if(mysqli_num_rows($result)){
        echo "<style> td {padding:10px;color:white;} th {padding:15px;color:white;}  </style>";
        echo "<table border=1 style= 'margin: 0 auto; height:50%; margin-top:8%; color:white; background-color:rgba(40,57,101,.9)'>";
        echo "<tr>";
        echo "<th>Balance</th>";
        echo "<th><form action='update_dlim.php' method='post'><button style='color:white ;
        background-color: rgba(255,255,255,.2);
        border-radius: 50px;
        display: flex;
        justify-content: center;
        align-items: center;
        height: 3em;
        width: 8em;
        font-size: large;
        font-weight: 600;' type='submit'>Daily Limit</button></form></th>";
        echo "<th><form action='update_min_bal.php' method='post'><button style='color:white ;
        background-color: rgba(255,255,255,.2);
        border-radius: 50px;
        display: flex;
        justify-content: center;
        align-items: center;
        height: 3em;
        width: 8em;
        font-size: large;
        font-weight: 600;' type='submit'>Mininum Balance</button></form></th>";
        echo "</tr>";
        while ($row=mysqli_fetch_array($result)){
            echo "<tr>";
            echo "<td>".$row['balance']."</td>";
            echo "<td>".$row['dlim']."</td>";
            echo "<td>".$row['min_bal']."</td>";
            echo "</tr>";
        } 
        echo "</table>";      
        mysqli_free_result($result);  
    }
}

mysqli_close($link);
?>

</body>