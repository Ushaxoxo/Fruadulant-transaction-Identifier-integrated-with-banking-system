<form action="update_min_bal2.php" method="post">
    <input type="number" name="mb" placeholder="New Minimum Balance"/>
    <button type="submit" class="button">Confirm</button>
</form>
