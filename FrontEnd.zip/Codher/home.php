
<head>
    <link rel="stylesheet" href="navstyle.css">
</head>
<div id="mySidenav" class="sidenav">
  <a href="javascript:void(0)" class="closebtn" onclick="closeNav()">&times;</a>
  <a href="myacc.php">My Account</a>
  <a class="active" href="home.php">Banking</a>
  <a href="his.php">History</a>
</div>

<span style="font-size:30px;cursor:pointer;color:rgba(40,57,101,.9);" onclick="openNav()">&#9776;</span>

<script>
function openNav() {
  document.getElementById("mySidenav").style.width = "250px";
}

function closeNav() {
  document.getElementById("mySidenav").style.width = "0";
}
</script>

<body style="background-image:url(bank3.jpg); background-repeat: no-repeat; background-size: cover;">
<form action="pinvalidate.php" method="post">
    <select name="t1">
        <option value=1>Cash In</option>
        <option value=2>Cash Out</option>
        <option value=3>Debit</option>
        <option value=4>Payment</option>
        <option value=5>Transfer</option>
    </select>
    <input placeholder="amount" type="number" name="amt"/>
    <select name="t2">
        <option value=1>Customer to Merchant</option>
        <option value=0>Customer to Customer</option>
    </select>
    <input placeholder="to: receiver account" type="text" name="racc"/>
    <button type="submit" class="button">Confirm</button>
</form>
</body>