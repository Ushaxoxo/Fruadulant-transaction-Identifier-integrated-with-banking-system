<?php
session_start();
$link=mysqli_connect("localhost","root","","codher");
$query="UPDATE accounts SET dlim='$_POST[dval]' WHERE acc_no='$_SESSION[an]'";
mysqli_query($link,$query);
mysqli_close($link);
header("Location: myacc.php");
?>