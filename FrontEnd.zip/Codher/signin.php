<?php
session_start();
$link=mysqli_connect("localhost","root","","codher");
$_SESSION['an']=$_POST['an'];
$_SESSION['pwd']=$_POST['pwd'];
$_SESSION['l']=0;
$query="SELECT * FROM accounts WHERE acc_no='$_SESSION[an]' and pass='$_SESSION[pwd]'";
$result=mysqli_query($link,$query);
$count=mysqli_num_rows($result);
if ($count>0){
    header("Location: home.php");
}
else{
    echo "Invalid credentials!!";
}
mysqli_close($link);
?>