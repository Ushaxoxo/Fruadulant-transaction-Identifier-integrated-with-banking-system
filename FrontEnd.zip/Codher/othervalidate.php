<?php
session_start();
$connection = mysqli_connect("localhost", "root", "", "codher");

$query = "SELECT balance,dlim,min_bal FROM accounts WHERE acc_no='$_SESSION[an]'";
$result = mysqli_query($connection, $query);

while ($row=mysqli_fetch_array($result)) {
   $bal = $row['balance'];
   $lim = $row['dlim'];
   $minbal = $row['min_bal'];
}
$no1=$bal-$_SESSION['amt'];
$_SESSION['l']+=$_SESSION['amt'];
$_SESSION['bal']=$bal;
$_SESSION['no1']=$no1;
if ($no1<$minbal){
    echo "Transaction failed: Insufficient balance!!";
    echo "balance: ".$bal;
}
elseif ($_SESSION['l']>$lim){
    echo "Transaction failed: Exceeding daily limit!!<br>";
    echo "daily limit: ".$lim;
    echo "<br>amount used today: ".$_SESSION['l'];
}
else{
    header("Location: trans.php");
}
//close the connection
mysqli_close($connection);
?>