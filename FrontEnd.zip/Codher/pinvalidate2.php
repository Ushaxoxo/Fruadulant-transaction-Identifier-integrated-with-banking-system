<?php
session_start();
$link=mysqli_connect("localhost","root","","codher");
$query="SELECT * FROM accounts WHERE pin='$_POST[p]'";
$result=mysqli_query($link,$query);
$count=mysqli_num_rows($result);
if ($count>0){
    header("Location: othervalidate.php");
}
else{
    echo "Wrong pin!!";
}
mysqli_close($link);
?>