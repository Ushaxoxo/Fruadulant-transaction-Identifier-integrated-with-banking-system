<head>
    <link rel="stylesheet" href="navstyle.css">
</head>
<div id="mySidenav" class="sidenav">
  <a href="javascript:void(0)" class="closebtn" onclick="closeNav()">&times;</a>
  <a href="myacc.php">My Account</a>
  <a href="home.php">Banking</a>
  <a class="active" href="his.php">History</a>
</div>

<span style="font-size:30px;cursor:pointer;color:rgba(40,57,101,.9);" onclick="openNav()">&#9776;</span>

<script>
function openNav() {
  document.getElementById("mySidenav").style.width = "250px";
}

function closeNav() {
  document.getElementById("mySidenav").style.width = "0";
}
</script>

<body style="background-image:url(bank3.jpg); background-repeat: no-repeat; background-size: cover;">
<?php
session_start();
$link=mysqli_connect("localhost","root","","codher");
$query="SELECT tid,(select acc_no from accounts where sid=sno),old_bal,new_bal,(select acc_no from accounts where transaction.rid=sno) FROM accounts,transaction WHERE sid=(select sno from accounts where acc_no='$_SESSION[an]')";
if($result=mysqli_query($link,$query)){
    if(mysqli_num_rows($result)){
        echo "<style> td {padding:10px;color:white;} th {padding:15px;color:white;}  </style>";
        echo "<table border=1 style= 'margin: 0 auto; height:50%; margin-top:8%; color:white; background-color:rgba(40,57,101,.9)'>";
        echo "<tr>";
        echo "<th>Transaction ID</th>";
        echo "<th>My Account</th>";
        echo "<th>Old Balance</th>";
        echo "<th>New Balance</th>";
        echo "<th>Receiver Account</th>";
        echo "</tr>";
        while ($row=mysqli_fetch_array($result)){
            echo "<tr>";
            echo "<td>".$row['tid']."</td>";
            echo "<td>".$row['acc_no']."</td>";
            echo "<td>".$row['old_bal']."</td>";
            echo "<td>".$row['new_bal']."</td>";
            echo "<td>".$_SESSION['racc']."</td>";
            echo "</tr>";
        } 
        echo "</table>";      
        mysqli_free_result($result);  
    }
}

mysqli_close($link);
?>
</body>