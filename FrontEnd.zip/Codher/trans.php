<?php
session_start();
$link=mysqli_connect("localhost","root","","codher");
$query1="INSERT INTO transaction(type_ci,type_co,type_d,type_p,type_t,type,old_bal,new_bal,sid,rid) VALUES(1,0,0,0,0,'$_SESSION[t2]','$_SESSION[bal]','$_SESSION[no1]',(select sno from accounts where acc_no='$_SESSION[an]'),(select sno from accounts where acc_no='$_SESSION[racc]'))";
$query2="INSERT INTO transaction(type_ci,type_co,type_d,type_p,type_t,type,old_bal,new_bal,sid,rid) VALUES(0,1,0,0,0,'$_SESSION[t2]','$_SESSION[bal]','$_SESSION[no1]',(select sno from accounts where acc_no='$_SESSION[an]'),(select sno from accounts where acc_no='$_SESSION[racc]'))";
$query3="INSERT INTO transaction(type_ci,type_co,type_d,type_p,type_t,type,old_bal,new_bal,sid,rid) VALUES(0,0,1,0,0,'$_SESSION[t2]','$_SESSION[bal]','$_SESSION[no1]',(select sno from accounts where acc_no='$_SESSION[an]'),(select sno from accounts where acc_no='$_SESSION[racc]'))";
$query4="INSERT INTO transaction(type_ci,type_co,type_d,type_p,type_t,type,old_bal,new_bal,sid,rid) VALUES(0,0,0,1,0,'$_SESSION[t2]','$_SESSION[bal]','$_SESSION[no1]',(select sno from accounts where acc_no='$_SESSION[an]'),(select sno from accounts where acc_no='$_SESSION[racc]'))";
$query5="INSERT INTO transaction(type_ci,type_co,type_d,type_p,type_t,type,old_bal,new_bal,sid,rid) VALUES(0,0,0,0,1,'$_SESSION[t2]','$_SESSION[bal]','$_SESSION[no1]',(select sno from accounts where acc_no='$_SESSION[an]'),(select sno from accounts where acc_no='$_SESSION[racc]'))";
if ($_SESSION['t1']==1){
    mysqli_query($link,$query1);
}
elseif ($_SESSION['t1']==2){
    mysqli_query($link,$query2);
}
elseif ($_SESSION['t1']==3){
    mysqli_query($link,$query3);
}
elseif ($_SESSION['t1']==4){
    mysqli_query($link,$query4);
}
elseif ($_SESSION['t1']==5){
    mysqli_query($link,$query5);
}
header("Location: update.php")

//mysqli_close($link);

?>