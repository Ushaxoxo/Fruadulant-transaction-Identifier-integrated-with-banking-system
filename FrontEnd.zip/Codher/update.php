<?php
session_start();
//echo $_SESSION['an'];

//echo $_SESSION['racc'];

//echo $_SESSION['amt'];
echo "Transaction successful";
$link=mysqli_connect("localhost","root","","codher");
$up1="UPDATE accounts SET balance = (balance - '$_SESSION[amt]') where acc_no='$_SESSION[an]'";
mysqli_query($link,$up1);
$up2="UPDATE accounts SET balance = (balance + '$_SESSION[amt]') where acc_no='$_SESSION[racc]'";
mysqli_query($link,$up2);

mysqli_close($link);
?>