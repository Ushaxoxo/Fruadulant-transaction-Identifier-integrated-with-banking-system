from flask import Flask, render_template, request
import pickle
import keras
from keras.models import load_model
import tensorflow as tf
import numpy as np

app = Flask('codeher')

model = load_model('games.h5')
graph = tf.compat.v1.get_default_graph()

@app.route("/")
def show_transaction_form():
    return render_template('Transaction.html')
@app.route('/results', methods=['GET','POST'])
def results():
    amount = float(request.form['amount'])
    type1 = request.form['type']
    if type1 == 'cashin':
        typea, typeb, typec, typed, typee = 1, 0, 0, 0, 0
    elif type1 == 'cashout':
        typea, typeb, typec, typed, typee = 0, 1, 0, 0, 0
    elif type1 == 'debit':
        typea, typeb, typec, typed, typee = 0, 0, 1, 0, 0
    elif type1 == 'payment':
        typea, typeb, typec, typed, typee = 0, 0, 0, 1, 0
    else:
        typea, typeb, typec, typed, typee = 0, 0, 0, 0, 1

    receiver = request.form['Receiver']
    if receiver == 'Merchant':
        rec = 1
    else:
        rec = 0

    fraud_detection = model.predict([[amount, typea, typeb, typec, typed, typee, rec, 213.00, -23000.00]], batch_size=1, verbose=0)

    return render_template('Result.html', amount=amount, type1=type1, receiver=receiver, fraud_detection=fraud_detection)

if __name__ == '__main__':
    app.run("localhost", "9999", debug=True)
